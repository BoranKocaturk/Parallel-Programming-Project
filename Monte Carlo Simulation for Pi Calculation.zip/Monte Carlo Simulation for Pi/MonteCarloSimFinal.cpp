#include <iostream>
#include <cstdlib>
#include <ctime>
#include <cmath>
#include <omp.h>

double monte_carlo_pi_parallel(int num_points) {
    int inside_circle = 0;
    double x, y;

    #pragma omp parallel private(x, y)
    {
        unsigned int seed = omp_get_thread_num();
        #pragma omp for reduction(+:inside_circle)
        for (int i = 0; i < num_points; i++) {
            x = static_cast<double>(rand_r(&seed)) / RAND_MAX;
            y = static_cast<double>(rand_r(&seed)) / RAND_MAX;

            if (x*x + y*y <= 1.0) {
                inside_circle++;
            }
        }
    }

    return 4.0 * inside_circle / num_points;
}

double monte_carlo_pi_serial(int num_points) {
    int inside_circle = 0;
    double x, y;

    for (int i = 0; i < num_points; i++) {
        x = static_cast<double>(rand()) / RAND_MAX;
        y = static_cast<double>(rand()) / RAND_MAX;

        if (x*x + y*y <= 1.0) {
            inside_circle++;
        }
    }

    return 4.0 * inside_circle / num_points;
}

int main() {
    int num_points;
    std::cout << "Enter the number of points: ";
    std::cin >> num_points;
    srand(time(NULL));

    double start_time_serial = omp_get_wtime();
    double pi_estimate_serial = monte_carlo_pi_serial(num_points);
    double end_time_serial = omp_get_wtime();

    std::cout << "Estimated Pi (Serial): " << pi_estimate_serial << std::endl;
    std::cout << "Execution Time (Serial): " << (end_time_serial - start_time_serial) << " seconds" << std::endl;

    double start_time_parallel = omp_get_wtime();
    double pi_estimate_parallel = monte_carlo_pi_parallel(num_points);
    double end_time_parallel = omp_get_wtime();

    std::cout << "Estimated Pi (Parallel): " << pi_estimate_parallel << std::endl;
    std::cout << "Execution Time (Parallel): " << (end_time_parallel - start_time_parallel) << " seconds" << std::endl;

    return 0;
}
